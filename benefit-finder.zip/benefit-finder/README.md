# Benefit Finder

A small static web app that matches a person's age, gender, state, category, income and occupation
with government and private schemes, scholarships, certificates and savings options, and shows how to
apply. It also has a life roadmap (age 0 to 100) showing what opens at each age.

No Aadhaar number is collected. Nothing is stored or sent anywhere; all matching runs in the browser.

## Project structure

```
benefit-finder/
  index.html      page structure and form
  css/style.css   styles, light and dark theme
  js/data.js      scheme, scholarship, certificate and finance data
  js/app.js       eligibility rules, rendering, roadmap
  vercel.json     clean deploy settings
```

## Run locally

Open `index.html` in a browser, or run a local server:

```
python3 -m http.server 8000
```

## Add or edit a benefit

Open `js/data.js` and add a line with `A(name, type, source, [minAge, maxAge], description, steps, link, rules)`.
Types: `S` scheme, `B` scholarship, `C` certificate, `F` finance. Source: `G` government, `P` private.
Steps are separated by `|`. Optional rules: `s` gender, `c` categories, `o` occupations, `i` max income (lakh),
`state`, `dis`, `chk`.

## Deploy on Vercel

1. Push this folder to a GitHub repository.
2. On vercel.com choose Add New, then Project, and import the repository.
3. Framework preset: Other. Leave build command and output directory empty. Deploy.

## Disclaimer

Rules, amounts and interest rates change. Confirm on the official site before applying.
This is general guidance, not financial or legal advice.
