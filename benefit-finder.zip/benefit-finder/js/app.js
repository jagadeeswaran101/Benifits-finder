/* App logic: eligibility matching, rendering, life roadmap, theme toggle */
var T={S:'Schemes',B:'Scholarships',C:'Certificates',F:'Finance'},P=null,cur='S',list=[];
function $(i){return document.getElementById(i)}
function st(i,p){
 if(i.s&&i.s!==p.g)return null; if(i.state&&i.state!==p.state)return null;
 if(p.age>i.a[1])return null;
 if(i.c&&!i.c.some(function(x){return x==='MIN'?p.min:x===p.cat}))return null;
 if(i.o&&i.o.indexOf(p.o)<0)return null; if(i.dis&&!p.dis)return null;
 if(i.i!=null&&p.inc>i.i)return null;
 if(p.age<i.a[0])return{k:'soon',t:'Opens at age '+i.a[0],r:2};
 return i.chk?{k:'chk',t:'Likely eligible: verify',r:1}:{k:'ok',t:'You are eligible',r:0};
}
function card(i,s,p){
 var l=(p&&p.state==='TN'&&i.lt)?i.lt:i.l;
 return '<article class="card"><div class="top"><span class="tag">'+(i.g==='G'?'Government':'Private')+'</span><span class="st '+s.k+'">'+s.t+'</span></div><h3>'+i.n+'</h3><p>'+i.d+'</p><details><summary>How to apply</summary><ol>'+i.h.map(function(x){return '<li>'+x+'</li>'}).join('')+'</ol></details><a class="btn o" href="'+l+'" target="_blank" rel="noopener">Official site</a></article>';
}
function render(){
 var g=$('gf').value;
 [].forEach.call($('tabs').children,function(b){b.setAttribute('aria-selected',b.dataset.k===cur)});
 if(cur==='R'){return roadmap()}
 var rows=list.filter(function(x){return x.i.t===cur&&(!g||x.i.g===g)}).sort(function(a,b){return a.s.r-b.s.r});
 $('out').innerHTML=rows.length?'<div class="grid">'+rows.map(function(x){return card(x.i,x.s,P)}).join('')+'</div>':'<div class="empty">No matches here for your details. Try changing your income, occupation or the Government/Private filter.</div>';
}
function stage(a){return a<6?'Early childhood':a<18?'School years':a<25?'Starting out':a<41?'Earning years':a<60?'Building security':'Senior years'}
function roadmap(){
 var a=P.age;
 $('out').innerHTML='<div class="rm"><label for="rg" style="font-weight:700">Drag to see what opens at each age, from birth to 100</label><div class="age" id="av"></div><input id="rg" type="range" min="0" max="100" value="'+a+'" style="width:100%"><h3 id="sg"></h3><div id="rl"></div></div>';
 function upd(){
  var v=+$('rg').value,g=$('gf').value;
  $('av').textContent='Age '+v;$('sg').textContent=stage(v);
  var ok=D.filter(function(i){return(!i.s||i.s===P.g)&&(!i.state||i.state===P.state)&&(!g||i.g===g)});
  var now=ok.filter(function(i){return i.a[0]<=v&&v<=i.a[1]&&i.t!=='B'||(i.t==='B'&&i.a[0]<=v&&v<=i.a[1])});
  var nx=ok.filter(function(i){return i.a[0]>v&&i.a[0]<=v+5}).sort(function(x,y){return x.a[0]-y.a[0]});
  $('rl').innerHTML='<h3 style="font-size:1.05rem;margin:1rem 0 .6rem">Open at this age ('+now.length+')</h3><div class="grid">'+now.map(function(i){return card(i,{k:'ok',t:'Open at age '+v},P)}).join('')+'</div>'+
  (nx.length?'<h3 style="font-size:1.05rem;margin:1.4rem 0 .6rem">Opening in the next 5 years</h3><div class="grid">'+nx.map(function(i){return card(i,{k:'soon',t:'Opens at age '+i.a[0]},P)}).join('')+'</div>':'');
 }
 $('rg').addEventListener('input',upd);upd();
}
$('f').addEventListener('submit',function(e){
 e.preventDefault();
 var age=parseInt($('age').value,10),inc=parseFloat($('inc').value);
 if(isNaN(age)||age<0||age>100){$('err').textContent='Enter an age between 0 and 100.';return}
 if(isNaN(inc)||inc<0){$('err').textContent='Enter your family income in lakh rupees, for example 2.5.';return}
 $('err').textContent='';
 P={age:age,inc:inc,g:$('g').value,state:$('state').value,cat:$('cat').value,o:$('o').value,min:$('min').checked,dis:$('dis').checked};
 list=[];D.forEach(function(i){var s=st(i,P);if(s)list.push({i:i,s:s})});
 var n=list.filter(function(x){return x.s.r<2}).length,name=$('nm').value.trim();
 $('sum').textContent=(name?name+', you':'You')+' qualify for '+n+' options today, and more open as you grow.';
 var t=$('tabs');t.innerHTML='';
 Object.keys(T).concat('R').forEach(function(k){
  var b=document.createElement('button');b.className='tab';b.dataset.k=k;b.setAttribute('role','tab');
  b.textContent=k==='R'?'Life roadmap':T[k]+' ('+list.filter(function(x){return x.i.t===k}).length+')';
  b.addEventListener('click',function(){cur=k;render()});t.appendChild(b);
 });
 cur='S';$('res').style.display='block';render();$('res').scrollIntoView({behavior:'smooth'});
});
$('gf').addEventListener('change',function(){if(P)render()});
(function(){var r=document.documentElement;try{var t=localStorage.getItem('th');if(t)r.setAttribute('data-theme',t)}catch(e){}
$('th').addEventListener('click',function(){var d=r.getAttribute('data-theme')==='dark'||(!r.getAttribute('data-theme')&&matchMedia('(prefers-color-scheme: dark)').matches);var n=d?'light':'dark';r.setAttribute('data-theme',n);try{localStorage.setItem('th',n)}catch(e){}})})();
